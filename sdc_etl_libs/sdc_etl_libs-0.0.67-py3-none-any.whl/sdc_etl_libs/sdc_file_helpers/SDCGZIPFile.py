import gzip
import io
import logging
import numpy as np
import pandas as pd
from sdc_etl_libs.sdc_dataframe.Dataframe import Dataframe, SDCDFTypes
from sdc_etl_libs.sdc_file_helpers.SDCFile import SDCFile
from sdc_etl_libs.sdc_data_schema.SDCDataSchema import SDCDataSchema


class SDCGZIPFile(SDCFile):

    def __init__(self, schema_, endpoint_schema_, file_obj_):

        self.schema = schema_
        self.endpoint_schema = endpoint_schema_
        self.file_obj = file_obj_
        self.gzip_file_obj = None

        self.args = SDCDataSchema.generate_file_output_args(self.schema, self.endpoint_schema)
        if self.args is None or self.args == {}:
            raise Exception("Missing GZIP Args.")

        if self.endpoint_schema["file_info"]["headers"]:
            self.resolve_for_header = 1
            self.args["header"] = 0
        else:
            self.resolve_for_header = 0
            self.args["header"] = None

        self.args["names"] = SDCDataSchema.get_field_names_for_file(self.schema)

    def get_file_size(self):
        """
        Gets the total number of records in a file. Total does not include header, if present.
        :return: Int. Number of records.
        """

        self.get_file_as_object()

        records = 0
        f = io.BufferedReader(self.gzip_file_obj)
        for line in f:
            records += 1

        records -= self.resolve_for_header

        logging.info(f"File contains {records:,} number of records (Does not include header, if present).")

        return records

    def get_file_as_object(self):
        """
        Creates GZIP object as opened stream from file object given to SDCGZIPFile.
        :return: GzipFile object.
        """

        self.gzip_file_obj = gzip.open(self.file_obj)
        self.file_obj.seek(0)

    def get_file_as_dataframe(self, start_row_=0, chunksize_=None):
        """
        Loads data from GZIP file object into an SDDCDataframe.
        :param start_row_: Int. Row number to start from. Default = 0.
        :param chunksize_: Int. Number of rows load to dataframe via
            iteration. If None, entire dataset will be loaded into
            dataframe. Default = None.
        :return: Either complete SDCDataframe object, or, generator
            that will yield a SDCDataframe (if chunksize_ given).
        """

        self.get_file_as_object()

        try:
            if chunksize_:
                for chunk in pd.read_csv(self.gzip_file_obj,
                                         index_col=False,
                                         dtype=np.object_,
                                         chunksize=chunksize_,
                                         skiprows=start_row_,
                                         **self.args):
                    df = Dataframe(SDCDFTypes.PANDAS, self.schema)
                    pandas_df = chunk
                    df.process_df(pandas_df)
                    yield df
            else:
                df = Dataframe(SDCDFTypes.PANDAS, self.schema)
                pandas_df = pd.read_csv(self.gzip_file_obj,
                                        index_col=False,
                                        dtype=np.object_,
                                        skiprows=start_row_,
                                        **self.args)
                df.process_df(pandas_df)
                return df

        except Exception as e:
            logging.error(f"Failed loading GZIP data to SDCDataframe. {e}")
