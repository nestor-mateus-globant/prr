
import csv
import logging
import os
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil import parser

class SDCFileHelpers:

    @staticmethod
    def convert_file_to_flattened_dict(file_object_, file_type_='csv',
                                       delimiter_=',', column_header_list_=None):
        """
        Converts a file object to a list of flattened dictionaries.

        :param file_object_: File object that contains the lines of data to
            be processed.
        :param file_type_: File type of object. Default = 'csv'.
        :param delimiter_: File delimiter of object. Default = ','.
        :param column_header_list_: List of columns headers. Default = None.
        :return: List of flattened dictionaries.
        """

        output = []

        if file_type_.lower() in ['txt', 'csv']:
            try:
                if column_header_list_:
                    reader = csv.DictReader(file_object_, delimiter=delimiter_,
                                            fieldnames=column_header_list_)
                else:
                    reader =csv.DictReader(file_object_, delimiter=delimiter_)

            except Exception as e:
                logging.error(e)
                logging.error(f"Failed flattening file.")

        else:
            raise Exception(f"Error flattening file to dict. '{file_type_}' "
                            f"currently not support in SDCFileHelpers")

        for line in reader:
            output.append(dict(line))

        return output

    @staticmethod
    def get_file_path(type_, path_):
        """
        Returns absolute file path for file type and relative path provided.
        Function uses this file a point of reference to determine the
        right absolute path.
        :param type_: Type of file to be retrieved. Options:
            'schema': Returns schema from schema directory.
            'sql': Returns sql from sql directory.
        :param path_: Path to file from the desired type_.
        :return: Path to file as string.
        """

        if type_ == 'schema':
            file_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), '..', 'schemas',
                path_
            )

        elif type_ == 'sql':
            file_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), '..', 'sql',
                path_
            )
 
        elif type_ == 'metadata':
            file_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), '..', 'metadata',
                path_
            )

        else:
            raise Exception("File type for get_file_path not supported.")

        if not os.path.exists(file_path):
            raise Exception("File provided does not exist.")

        return file_path

    @staticmethod
    def compare_json_schema(obj1,obj2,format="json"):
        """
        :params obj1/obj2 two objects to compare
        :returns 0 for no difference detected, 1 - difference found
        """
        if len(obj1)!=len(obj2):
            logging.info(f"NUMBER OF KEYS DIDN'T MATCH!!")
            return True

        if format=="json":
            for key, value in obj1.items():
                if key not in obj2:
                    logging.info(f"KEY '{key}' NOT FOUND!!")
                    return True
                elif key in obj2 and obj1[key]==obj2[key]:
                    logging.info(f"KEY '{key}' MATCH FOUND!")
                    continue
                elif isinstance(obj1[key], dict) and isinstance(obj2[key], dict):
                    if SDCFileHelpers.compare_json_schema(obj1[key],obj2[key]) == 1:
                        return True
                elif isinstance(obj1[key], list) and isinstance(obj2[key], list):
                    if SDCFileHelpers.compare_json_schema(obj1[key],obj2[key],"list") == 1:
                        return True
                elif type(obj1[key])!=type(obj2[key]):
                    logging.info(f"KEY '{key}' DIDN'T MATCH!!")
                    return True
                elif value != obj2[key]:
                    logging.info(f"KEY '{key}' DIDN'T MATCH!!")
                    return True
        elif format=="list":
            for key, val in enumerate(obj1):
                if val not in obj2:
                    logging.info(f"KEY '{key}' NOT FOUND!!")
                    return True
            for key, val in enumerate(obj2):
                if val not in obj1:
                    logging.info(f"KEY '{key}' NOT FOUND!!")
                    return True
                # this could be expanded with additional cases to iterated deeper through lists of dictionaries
        return False

    @staticmethod
    def get_path_on_date_hive_partitions(prefix_, date_hive_partitions_, partition_to_process_, run_datetime_,
                                         time_unit_look_back_: int = 0):
        """
        Creates a complete path including calculated date hive partition to be processed.
        :param prefix_: The actual set prefix, before date hive partitions.
        :param date_hive_partitions_: List. Ordered list with the present date hive partitions in the path to be read.
        :partition_to_process_: One of the date hive partitions from the list provided in the parameter date_hive_partitions_.
        :param run_datetime_: String or Datetime object. Datetime to generate partition_to_process_ from.
        :param time_unit_look_back_: Int. Time unit to subtract from run run_datetime_. Default = 0.
        :return: complete_path. Complete path concatenating set prefix and calculated date hive partition to be processed.
        """
        datetime_to_process = SDCFileHelpers.get_datetime_to_process(partition_to_process_, run_datetime_, time_unit_look_back_)
        year = "year=%s/" % (datetime_to_process.strftime("%Y"))
        month = "month=%s/" % (datetime_to_process.strftime("%m"))
        day = "day=%s/" % (datetime_to_process.strftime("%d"))
        hour = "hour=%s/" % (datetime_to_process.strftime("%H"))

        complete_path = prefix_
        for hive_partition in date_hive_partitions_:
            if hive_partition == "year":
                complete_path += year
            elif hive_partition == "month":
                complete_path += month
            elif hive_partition == "day":
                complete_path += day
            elif hive_partition == "hour":
                complete_path += hour
            if hive_partition == partition_to_process_:
                return complete_path

    @staticmethod
    def get_datetime_to_process(partition_to_process_, run_datetime_, time_unit_look_back_: int = 0):
        """
        Calculates the appropriate truncated datetime from datetime_ passed in.
        :param partition_to_process_: The base time part, to subtract one unit from current date time value.
        :param run_datetime_: String or Datetime object. Datetime to generate partition_to_process_ from.
        :param time_unit_look_back_: Int. Time unit to subtract from run run_datetime_. Deafault = 0.
        :return: A datetime object.
        """

        if type(run_datetime_) == str:
            run_datetime_ = parser.parse(run_datetime_)

        try:
            partition_to_process = partition_to_process_.lower()
            if partition_to_process == "hour":
                return run_datetime_ - timedelta(hours=time_unit_look_back_)
            elif partition_to_process == "day":
                return run_datetime_ - timedelta(days=time_unit_look_back_)
            elif partition_to_process == "month":
                return datetime.combine(run_datetime_ + relativedelta(months=-time_unit_look_back_), datetime.min.time())
            elif partition_to_process == "year":
                return datetime.combine(run_datetime_ + relativedelta(years=-time_unit_look_back_), datetime.min.time())

        except Exception as e:
            logging.info(f"The given partition_to_process_ {partition_to_process_} is not in the options.")

