import logging
import pandas as pd
from sdc_etl_libs.sdc_dataframe.Dataframe import Dataframe, SDCDFTypes
from sdc_etl_libs.sdc_file_helpers.SDCFile import SDCFile


class SDCJsonFile(SDCFile):
    type = None
    file_name = None
    file_path = None
    file_obj = None
    schema = None
    endpoint_schema = None
    df = None
    endpoint_type = None

    def __init__(self, schema_, endpoint_schema_, file_name_, file_path_,
                 file_obj_):
        """
            Creates an SDCJsonFile object representing a JOSN file.
            :param schema_: Json schema of the data.
            :param endpoint_schema_: The endpoint schema of the source
            :param file_name_: Name of the file
            :param file_path_: Path you wish to write too
            :param file_obj_: Raw file object
            :return: SDCFILE Json File
        """
        self.schema = schema_
        self.lines = endpoint_schema_["file_info"]["lines"] or False if endpoint_schema_ else False
        self.file_name = file_name_
        self.file_path = file_path_
        self.file_obj = file_obj_
        self.endpoint_schema = endpoint_schema_

    def get_file_size(self):
        pass

    def get_file_as_object(self):
        """
        Writes out the contents of the dataframe into Json File like object.
        :return: File Like object (BufferIO)
        """
        pass

    def get_file_as_dataframe(self):
        """
         Converts a json file object to a dataframe.
         :return: A fully processed SDCDataframe.
         """
        data = []
        df = Dataframe(SDCDFTypes.PANDAS, self.schema)

        try:
            self.file_obj.seek(0)
            pandas_df = pd.read_json(self.file_obj, lines=self.lines)
            df.process_df(pandas_df)

        except Exception as e:
            logging.error(f"Failed loading json to dataframe. {e}")
        return df
